# Todo-List-App
• This Todo List App is using Firebase authentication for user registration and login.
<br/>• It allows users to add and update a task with title, details, and time.
<br/>• All data is stored in a Firebase realtime database.
<br/>• UI is well designed with a launch-page animation
<br/> <br/> <img src="https://user-images.githubusercontent.com/63463317/114271776-bda41480-9a45-11eb-875c-6450efc17222.png" width="300">
&nbsp; &nbsp; <img align="top" src="https://user-images.githubusercontent.com/63463317/114272270-1c6a8d80-9a48-11eb-8a65-fecb4045081b.png" width="500">

<br/> <br/>
<br/>• A sample gif of how to operate the app

![demo](https://github.com/muyij615/media-file/blob/main/Desktop/ezgif.com-gif-maker.gif)


